# Changelog

## 0.9.5

* zero initialize member variables from base classes

## 0.9.4

* add random agent script
* add example Dockerfile

## 0.9.3

* changed pyglet dependency to `pyglet~=1.4.8`
* fix issue with procgen thinking it was installed in development mode and attempting to build when installed from a pypi package
* make procgen more fork safe when `num_threads=0`

## 0.9.2

* fixed type bug in interactive script that would sometimes cause the script to not start

## 0.9.1

* initial release
