// stub function to compile when coinrun_old is missing
void coinrun_old_init(int rand_seed) {
}