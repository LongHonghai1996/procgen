```
Many Game Asset Packs
Author: kenney
CC0: https://www.kenney.nl/assets

Frog Asset
Author: GameArtGuppy.com
CC-BY 4.0: https://www.gameartguppy.com/shop/frog-lilypad/

Food Icons
Author: thekingphoenix
CC0: https://opengameart.org/content/icons-food

Space Background
Author: ansimuz
CC0: https://opengameart.org/content/space-background-3

Sci-Fi Background
Author: ansimuz
CC0: https://ansimuz.itch.io/sideview-sci-fi

Mountain Background
Author: ansimuz
CC-BY 4.0: https://ansimuz.itch.io/mountain-dusk-parallax-background

Forest Background
Author: ansimuz
CC-BY 4.0: https://ansimuz.itch.io/parallax-forest

Background
Author: rubberduck
CC0: https://opengameart.org/content/background-from-glitch-assets

Space Backgrounds
Author: Rawdanitsu
CC0: https://opengameart.org/content/space-backgrounds-3

Snow Background
Author: ramses2099
CC0: https://opengameart.org/content/background-2

Top-Down Backgrounds
Author: davis123
CC-BY 3.0: https://opengameart.org/content/backgrounds-topdown-games

Water Backgrounds
Author: rh0
CC0: https://opengameart.org/content/few-water-backgrounds-1366%C3%97768

Water Backgrounds
Author: Alucard
CC-BY 3.0: https://opengameart.org/content/2d-background-underwater

Water Backgrounds
Author: SugarMoonWitch
CC-BY 3.0: https://opengameart.org/content/underwater-bg

Water Backgrounds
Author: lzubiaur
CC0: https://opengameart.org/content/underwater-background-0

2D Background Set
Author: Alucard
CC-BY 3.0: https://opengameart.org/content/2d-backgrounds-set

Parallax 2D Backgrounds
Author: CraftPix.net 2D Game Assets
OGA-BY 3.0: https://opengameart.org/content/parallax-2d-backgrounds

Fantasy Cartoon Game Backgrounds
Author: CraftPix.net 2D Game Assets
OGA-BY 3.0: https://opengameart.org/content/fantasy-cartoon-game-backgrounds

Beach Backgrounds
Author: CraftPix.net 2D Game Assets
OGA-BY 3.0: https://opengameart.org/content/beach-2d-backgrounds

Battle Backgrounds
Author: Nidhoggn
CC0: https://opengameart.org/content/backgrounds-3

Sunrise Background
Author: tgfcoder
CC0: https://opengameart.org/content/morning-sunrise-background
```